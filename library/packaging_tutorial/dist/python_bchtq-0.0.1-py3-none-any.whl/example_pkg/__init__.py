from unicodedata import name


name = 'python-bchtq'