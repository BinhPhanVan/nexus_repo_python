def sum(a, b):
    return a + b

def hello():
    print("Hi everyone of group 19NH11")

def member_team():
    print("Include 4 members: ")
    print("\tPhan Van Binh")
    print("\tLe Thanh Quy")
    print("\tNguyen Thanh Co")
    print("\tTran Nguyen Anh Trinh")
    print("\tLe Van Huy")
