# Write some basic function 
# Install it up to Nexus Repository
