from unicodedata import name


name = 'python-bchtq'
from bchtq import *